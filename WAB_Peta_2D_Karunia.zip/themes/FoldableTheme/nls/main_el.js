// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"Foldable Theme",_layout_default:"\u03a0\u03c1\u03bf\u03b5\u03c0\u03b9\u03bb\u03b5\u03b3\u03bc\u03ad\u03bd\u03b7 \u03b4\u03b9\u03ac\u03c4\u03b1\u03be\u03b7",_layout_layout1:"\u0394\u03b9\u03ac\u03c4\u03b1\u03be\u03b7 1",_localized:{}}});