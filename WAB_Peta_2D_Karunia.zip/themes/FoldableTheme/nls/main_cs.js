// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"Rozkl\u00e1dac\u00ed motiv",_layout_default:"V\u00fdchoz\u00ed rozvr\u017een\u00ed",_layout_layout1:"Rozvr\u017een\u00ed 1",_localized:{}}});